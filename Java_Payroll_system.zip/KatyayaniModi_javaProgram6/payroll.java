/* Program 6
 * Vinisha Punuru
 */
package application;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Scanner;

import application.Hourly;
import application.Salaried;
import application.employee;
import application.payroll;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;


    public class payroll extends Application {

	ArrayList<employee> employees = new ArrayList<employee>();
	ArrayList<employee> firedEmployees = new ArrayList<employee>();
	File Database;
	String loginUser;
	Stage st;
	employee employe ;
	int noofemp = 0;
	
	String empFile ="employee.txt";
	 String loginName1;
	 double salary1;
	 String employeeName1;
	 String date1;
	 String password1;
	 int employeeID1;
	 int controlVariable;
	 static ArrayList<employee> empList = new ArrayList<employee>();
	 static ArrayList<employee> remove_empList = new ArrayList<employee>();
	 Scanner scanner=new Scanner(System.in);
	 employee currentEmployee;
	 int currentID;

	public payroll(){
		
	}
	
	

	// pane1 - login
	
	GridPane loginpane = new GridPane();
	
    Label usernamelabel = new Label("Username"); 
	TextField usernamefield = new TextField();
	Label passwordlabel = new Label("Password");
	PasswordField passwordfield = new PasswordField();
	Button loginbutton = new Button("Login");
	
	

	// pane2 - boss 
	
	 VBox bosspane = new VBox(5);
	 
	 Text bosslogin = new Text("Boss Loggedin");
	 Button addempbutton = new Button("Add Employee");
	 Button changeempbutton = new Button("Change Employee Data");
	 Button emplistbutton = new Button("View Employee list");
	 Button terminateEmp = new Button("Terminate Employee");
	 Button payEmployee = new Button("Pay Employee");
	 Button logoutbutton = new Button("Log Out");	
	 
	 
	 //pane 3 - create employee
	 
	 GridPane newemppane = new GridPane();
	 
	 Text addnewemptext = new Text("Add New Employee");
	 Label firstnamelabel = new Label("First Name");
	 TextField firstnamefield = new TextField();
	 Label lastnamelabel = new Label("Last Name");
	 TextField lastnamefield = new TextField();
	 Label newusernamelabel = new Label("User Name");
	 TextField newusernamefield = new TextField();
	 Label newpasswordlabel = new Label("Password");
	 TextField newpasswordfield = new PasswordField();
	 Label reenterpasslabel = new Label("Re-enter Password");
	 PasswordField reenterpassfield = new PasswordField();
	 Label salarylabel = new Label("Salary");
	 TextField salaryfield = new TextField();
	 Label savingslabel = new Label("Savings");
	 TextField savingsfield = new TextField();
	 RadioButton hourlybutton = new RadioButton("Hourly");
	 RadioButton salarybutton = new RadioButton("Salaried");
	 ToggleGroup emptype = new ToggleGroup();
	 //hourlybutton.setToggleGroup(emptype);
	 //salarybutton.setToggleGroup(emptype);
	 Button addbutton= new Button("ADD");
	 Button goback = new Button("Go Back");
	 
	 
	 // pane4 - make changes
	 
	 GridPane changeemppane = new GridPane();
		
	 Text changeempdatatext = new Text("Change Employee Data");	
	 Label empidlabel = new Label("Employee ID");
	 TextField empidfield = new TextField();
	 Label updatefirstnamelabel = new Label("First Name");
	 TextField updatefirstnamefield = new TextField();
//	 Label updatelastnamelabel = new Label("Last Name");
//	 TextField updatelastnamefield = new TextField();
	 Label updatesalarylabel = new Label("Salary");
	 TextField updatesalaryfield = new TextField();
	 Button updatebutton = new Button("Update");
	 Button updateback = new Button("Back");
	 
	 GridPane terminateemppane = new GridPane();
		
	 Text terminateempdatatext = new Text("Remove Employee");	
	 Label empidlabel_remove = new Label("Employee ID");
	 TextField empidfield_remove = new TextField();
	 Button removebutton = new Button("Remove");
	 Button terminateback = new Button("Back");
	 
	 
	 
	 //pane5 - list
	 
	 VBox listpane = new VBox(5);
	 
	 Text emplisthead = new Text("Employees List ");
	 TextArea listemptext = new TextArea();
	 Button listback = new Button("Back");
	
	 VBox logoutpane = new VBox(5);
	 
	 Text logouthead = new Text("List of Employees Fired ");
	 TextArea logouttext = new TextArea();
	 Button logoutback = new Button("Click Login");
	 
	 VBox payrollpane = new VBox(5);
	 
	 Text payrollhead = new Text("Payroll Management ");
	 TextArea payrolltext = new TextArea();
	 Button payrollback = new Button("Back");
	
	 
	 // pane6 - nonboss 
	 
	 VBox nonbosspane = new VBox(5);
	 
	 Text emplogintext = new Text("Employee Loggedin");
	 TextArea viewemployee = new TextArea();
	 Button logoutemployee = new Button("Log Out");
	 
	 // start
	 
	 public void start(Stage st) throws IOException, ClassNotFoundException
	 {		 
		 try {
				readInputfile();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		 
		// buildGui();
		 
	     Scene loginscene = new Scene(loginpane, 400,400);
		 loginpane.add(usernamelabel,1,1);
		 loginpane.add(usernamefield, 2, 1);
		 loginpane.add(passwordlabel,1,2);
		 loginpane.add(passwordfield,2,2);
		 loginpane.add(loginbutton, 2, 4);
		 
		 
		 
		 Scene bossscene = new Scene(bosspane, 400,400);
		 bosspane.getChildren().addAll(bosslogin, addempbutton, changeempbutton, emplistbutton,terminateEmp,payEmployee,logoutbutton );
	
		 Scene newempscene = new Scene(newemppane, 400,400);
		 newemppane.add(addnewemptext, 2, 1);
		 newemppane.add(firstnamelabel, 1,2);
		 newemppane.add(firstnamefield, 2,2);
		 newemppane.add(newusernamelabel,1,4);
		 newemppane.add(newusernamefield,2,4);
		 newemppane.add(newpasswordlabel,1,5);
		 newemppane.add(newpasswordfield, 2,5);
		 newemppane.add(reenterpasslabel,1,6);
		 newemppane.add(reenterpassfield, 2,6);
		 newemppane.add(salarylabel, 1,7);
		 newemppane.add(salaryfield, 2,7);
		 newemppane.add(salarybutton, 1,8);
		 newemppane.add(hourlybutton, 2,8);
		 newemppane.add(addbutton, 1,11);
		 newemppane.add(goback,2,11);		 
		 
		 Scene changeempscene = new Scene(changeemppane,400,400);
		 changeemppane.add(changeempdatatext, 2, 1);
		 changeemppane.add(empidlabel, 1, 2);
		 changeemppane.add(empidfield, 2, 2);
		 changeemppane.add(updatefirstnamelabel, 1, 3);
		 changeemppane.add(updatefirstnamefield, 2, 3);
//		 changeemppane.add(updatelastnamelabel, 1, 4);
//		 changeemppane.add(updatelastnamefield, 2, 4);
		 changeemppane.add(updatesalarylabel,  1, 5);
		 changeemppane.add(updatesalaryfield, 2, 5);
		 changeemppane.add(updatebutton, 1, 7);
		 changeemppane.add(updateback, 2 , 7);
		 
		 Scene terminateempscene = new Scene(terminateemppane,400,400);
		 terminateemppane.add(terminateempdatatext, 2, 1);
		 terminateemppane.add(empidlabel_remove, 1, 2);
		 terminateemppane.add(empidfield_remove, 2, 2);
		 terminateemppane.add(removebutton, 1, 7);
		 terminateemppane.add(terminateback, 2 , 7);
		 
	     Scene emplistscene = new Scene(listpane, 400,400);
	     listpane.getChildren().addAll(emplisthead, listemptext,listback);
	     
	     Scene payrollscene = new Scene(payrollpane, 400,400);
	     payrollpane.getChildren().addAll(payrollhead, payrolltext,payrollback);
	     
	     Scene logoutscene = new Scene(logoutpane, 400,400);
	     logoutpane.getChildren().addAll(logouthead, logouttext,logoutback);
	     
	   
	     
		 Scene nonbosscene = new Scene(nonbosspane,400,400);
		 nonbosspane.getChildren().addAll(emplogintext,viewemployee,logoutemployee);
		 
	
		 
		 loginbutton.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					// TODO Auto-generated method stub
					// st.setScene(bossscene);
					int i= dologin(usernamefield.getText());
					if (i==1)
					{
						st.setScene(bossscene);
						usernamefield.setText(null);
						passwordfield.setText(null);
					}
					else if (i >1)
					{
						st.setScene(nonbosscene);
						for(employee ee: empList){
							if(ee.employeeID == i-1) {
							viewemployee.appendText(ee.toString()+'\n');
							 System.out.println(ee);}
							usernamefield.setText(null);
							passwordfield.setText(null);
					}
					
					}
				}
		 }
				 );
		 
		 addempbutton.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					// TODO Auto-generated method stub
					st.setScene(newempscene);
				}
		} );
		 
		 
		 
		 changeempbutton.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					// TODO Auto-generated method stub
					st.setScene(changeempscene);					
				}
			} );
		 terminateEmp.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					// TODO Auto-generated method stub
					st.setScene(terminateempscene);					
				}
			} );
		 
		 
		 emplistbutton.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					 st.setScene(emplistscene);
					 listemptext.setText(null);
					 System.out.println("Employees List: ");
					 for(employee ee: empList){
						 listemptext.appendText(ee.toString()+'\n');
						 System.out.println(ee);
					 }
				}
		} );
		 
		 payEmployee.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					 st.setScene(payrollscene);
					 try {
						payEmployees();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					payrolltext.setText("Payroll is successfull genrated."+'\n'+"Generated document is available under src as Database.txt");
					 }
				}
		 );
		 
		 logoutbutton.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					 st.setScene(logoutscene);
					 logouttext.setText(null);
					 System.out.println("List of employees Fired: ");
					 for(employee ee: remove_empList){
						 logouttext.appendText(ee.toString()+'\n');
						 System.out.println(ee);
					 }
				}
		} );
		 
		 
	
		 
		 
		 logoutemployee.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					
		        		st.setScene(loginscene);
				}
				}
				 
		 );
		 
		 
		 addbutton.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					// TODO Auto-generated method stub
							char salType='A';
							if(salarybutton.isSelected())
							   {
								salType ='S';
							   }
							   else if(hourlybutton.isSelected())
							   {
								   salType ='H';
						      }
			int controlVariable = 0;
			try {
				controlVariable = newEmployee(newusernamefield.getText(), firstnamefield.getText(), salaryfield.getText(),newpasswordfield.getText(),reenterpassfield.getText(),salType);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}					
						  if (controlVariable==3)
						  {
							  System.out.println("Employee added");
							  lastnamefield.setText(null);
						    	 usernamefield.setText(null);
						    	 firstnamefield.setText(null);
						    	 passwordfield.setText(null);
						    	 reenterpassfield.setText(null);
						    	 salaryfield.setText(null);
						  
						  }
						   else if (controlVariable==2)
						   {
							   for (employee e1:empList)
								   System.out.println(e1);
							   Alert alert = new Alert(AlertType.CONFIRMATION);
							   alert.setTitle("Information Dialog");
							   alert.setHeaderText("Look, a Confirmation Dialog with Custom Actions");
							   alert.setContentText("Password mismatch. Re-enter details");
							 System.out.println("Password mismatch. Re-enter details");
					    	 lastnamefield.setText(null);
					    	 usernamefield.setText(null);
					    	 firstnamefield.setText(null);
					    	 passwordfield.setText(null);
					    	 reenterpassfield.setText(null);
					    	 salaryfield.setText(null);
							 }
						   else if (controlVariable==1)
							   System.out.println("Employee Already exists"); 
						  }

			
				} );
		 
		 
		 
		 updatebutton.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					double salary = Double.valueOf(updatesalaryfield.getText());
					int employeeID1 = Integer.parseInt(empidfield.getText());
					changeEmployeeData(employeeID1,updatefirstnamefield.getText(),salary);
					empidfield.setText(null);
					updatesalaryfield.setText(null);
					updatefirstnamefield.setText(null);
				}
				} );
		 removebutton.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					int employeeID1 = Integer.parseInt(empidfield_remove.getText());
					TerminateEmpolyee(employeeID1);
				}
				} );
		 
		 goback.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					// TODO Auto-generated method stub
					st.setScene(bossscene);
				}
				 
				} );
		 
		 updateback.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				// TODO Auto-generated method stub
				st.setScene(bossscene);
			}
		});
		 terminateback.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					// TODO Auto-generated method stub
					st.setScene(bossscene);
				}
			});
		 
		 listback.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					// TODO Auto-generated method stub
					st.setScene(bossscene);
				}				 
			});
		 payrollback.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					// TODO Auto-generated method stub
					st.setScene(bossscene);
				}				 
			});
		 logoutback.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					// TODO Auto-generated method stub
					st.setScene(loginscene);
				}				 
			});
		 
		 
		 
		 try {
				FileInputStream fis= new FileInputStream(new File("Database.txt"));
				 ObjectInputStream ois=new ObjectInputStream(fis);
			    // employees=(ArrayList<employee>)ois.readObject();
				// Employee.nextID = (int)ois.readObject();
				
				 ois.close();
				 fis.close();
				 st.setScene(loginscene);
				 st.setTitle("Employee Payroll Application");
				 st.show();
				}
				
				
			catch (FileNotFoundException e) {
				System.out.println("\nNo Database created .. Creating a new Database");
				System.out.println("\nEmployee Database created");
				System.out.println("\nDatabase empty");
				st.setScene(newempscene);
				st.setTitle("Employee Payroll Application");
				st.show();
			}
	 }
			  
		
	
	public static void main(String[] args) {
		
		   System.out.println("Project: Employee Payroll System");
		   System.out.println("Author:  Katyayani Modi");  
		   launch(args);
	}
	

	public void  readInputfile() throws IOException
	{
		File file=new File(empFile);
	 	try {  	
			Scanner sc = new Scanner( file );   
	        while(sc.hasNext()) {
	        	employeeID1 = sc.nextInt();
				loginName1 = sc.next();
				salary1 = sc.nextDouble();
				password1= sc.next();
				date1 = sc.next();
				employeeName1 = sc.next();
				Salaried currentEmployee = new Salaried(employeeID1, loginName1, salary1, date1, employeeName1,password1);
				empList.add(currentEmployee);				
			}
	        System.out.println("employees added to arraylist");
	        for(employee e:empList) {
				System.out.println(e);
			}
	        employee.nextID= employeeID1+1;
			sc.close();
	 	}
		catch(FileNotFoundException e) {
			System.out.println("employees.txt is not found");
			System.out.println("Enter login name, salary, name of the boss: ");
			loginName1 = scanner.next();
			salary1 = scanner.nextDouble();
			employeeName1 = scanner.next();
			password1 = scanner.next();
			Salaried currentEmployee = new Salaried(loginName1, salary1, employeeName1,password1);
			empList.add(currentEmployee);
			System.out.println("\n Boss is added successfully");
			System.out.println("["+currentEmployee.toString()+"]");
			file.createNewFile();
} 
	}
	
	
	 private int dologin(String username) {
			boolean isValidUser = false;
			for(employee e:empList){
				if(e.loginName.equals(username)) {
					currentEmployee = e;
					currentID = e.employeeID;
					isValidUser = true;
					System.out.println(" Login is successful");
					return currentID+1;
					
				}
			}
//			if(!isValidUser) {
//				System.out.println(" Login is unsuccessful");
//			}
			System.out.println(" Login is unsuccessful");
			return 0;

}
	 /**
	  * Function:    newEmployee()
	  * Description: Function to add new employees to the database
	  * Error Conditions: None 
	 * @throws Exception */ 
	 private int newEmployee(String loginName1, String employeeName1, String salary, String password1,String confirmPassword,char salType) throws Exception{		
		 	boolean isEmployeeExist= false;
		 	
		 	double salary1 = Double.valueOf(salary);
			for(employee e:empList) {
				if (loginName1.equals(e.loginName)) {
					System.out.println("Employee is alredy exist");
					isEmployeeExist = true;
					return 1;
					}
			}
			if(isEmployeeExist == false){
				String passwordComparison = getNewPassword(password1,confirmPassword);
				if (passwordComparison =="Fail")
				{
					System.out.println("Password Mismatch");
					return 2;
				}
				else if (salType=='H') 
				{
					 currentEmployee = new Hourly(loginName1, salary1, employeeName1, passwordComparison);
					 empList.add(currentEmployee);
					//employee.nextID++;
				}
				else if (salType=='S')
				{
					 currentEmployee = new Salaried(loginName1, salary1, employeeName1,passwordComparison);	
					 empList.add(currentEmployee);
					//employee.nextID++;
				}
			
			}
			return 3;
	}
	 /**
	  * Function:    changeEmployeeData()
	  * Description: Function to display modify the employee name or salary.
	  * Error Conditions: None */ 
	 private void changeEmployeeData(int employeeID1,String employeename1, double salray1){
		 for(employee e:empList) {
				if (employeeID1==e.employeeID) {
					e.employeeName=employeename1;
					e.salary=salray1;
					} 
		 	}	
	 	}
	 /**
	  * Function:    subTerminateEmpolyee()
	  * Description: subfunction for terminate employee logic
	  * Error Conditions: None */
	 private void TerminateEmpolyee(int employeeID2) {
	 	for(employee e:empList) {
	 		if (e.employeeID == employeeID2){
	 			currentEmployee=e;   
	 			break;
	 		}
	 	}
	   empList.remove(currentEmployee);
	   remove_empList.add(currentEmployee);
	 }
	 /**
	  * Function:    payEmployees()
	  * Description: function to employee salary 
	  * Error Conditions: None */
	 private void payEmployees() throws IOException {//throws IOException {
	 			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	 			LocalDate localDate = LocalDate.now();
	 			String current_date = dtf.format(localDate);
	 			System.out.println("\t PAYROLL REPORT " + "\t DATE: "+current_date);
	 			PrintWriter p = new PrintWriter(new File("EmployeePayroll.txt"));
	 			p.println("\tNAME\t\t\tPAY\t\t\tID");
	 			for(employee e:empList){
	 					if(e.employeeID==0) {
	 						Salaried sal = new Salaried(e.loginName ,e.salary, e.employeeName, e.password);
	 						double pay = sal.getPay();
	 						System.out.println("\tNAME\t\t\tPAY\t\t\tID");
	 						System.out.println("\n");
	 						System.out.println("\t"+sal.employeeName+"\t\t\t"+pay+"\t\t\t"+sal.employeeID);
	 						p.println("\t"+sal.employeeName+"\t\t\t"+pay+"\t\t\t"+sal.employeeID);
	 				} else {
	 					Hourly hr = new Hourly(e.loginName ,e.salary, e.employeeName, e.password);
	 					double pay = hr.getPay();
	 					System.out.println("\tNAME\t\t\tPAY\t\t\tID");
	 					System.out.println("\n");
	 					System.out.println("\t"+hr.employeeName+"\t\t\t"+pay+"\t\t\t"+hr.employeeID);
	 					p.println("\t"+hr.employeeName+"\t\t\t"+pay+"\t\t\t"+hr.employeeID);
	 				}
	 			}
	 			p.close();
	 					
	 	}
	 

/**
 * Function:    getNewPassword()
 * Description: subfunction for updateEmployee function to update employee salary 
 * Error Conditions: None 
 * @throws Exception */
private String getNewPassword(String password1, String password2 ) throws Exception {
	boolean retval= false;
	String encoded1;
	MessageDigest digest = MessageDigest.getInstance("SHA-256");
	byte[] hash1 = digest.digest(password1.getBytes(StandardCharsets.UTF_8));
	String encoded = Base64.getEncoder().encodeToString(hash1);
	
	byte[] hash2 = digest.digest(password2.getBytes(StandardCharsets.UTF_8));
	encoded1 = Base64.getEncoder().encodeToString(hash2);
	
	retval = Arrays.equals(hash1, hash2);
	if (retval == true)
	{
		return encoded1;
	}
	else 
		return "Fail";	
}
  }// end of the class