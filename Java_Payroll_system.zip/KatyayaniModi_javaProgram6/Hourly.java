package application;
import java.text.DecimalFormat;
import java.util.Scanner;

public class Hourly extends employee{
	
	Hourly(String login, double salary1, String name, String password1){
		super(login,salary1,name,password1);	  
		}

	/**
	 * Function:    getPay()
	 * Description: function to calculate the pay of an employee
	 * Error Conditions: None */
	public double getPay() {
		double pay;
		double payrate = 15;
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter number of hours: ");	
		double hrs=sc.nextDouble();
		pay = payrate * hrs;
		DecimalFormat df = new DecimalFormat("###.##");	// convert number to two decimal place
		//System.out.println("Salary in hourly class: "+df.format(pay));		
			
		return pay; // KS-need to update it
		
		
	}
	

}

