package application;
import java.text.DecimalFormat;

public class Salaried extends employee{
	
	public Salaried(String loginName1, double salary1, String employeeName1, String password1)	{
		super(loginName1,salary1,employeeName1,password1);	
	}
	public Salaried(int employeeID1, String loginName1,double salary1, String date1,String employeeName1, String password1) {
		super(employeeID1,loginName1,salary1,date1,employeeName1,password1);	
	}
	/**
	 * Function:    getPay()
	 * Description: function to calculate the pay of an employee
	 * Error Conditions: None */
	public double getPay() {
		double pay;
		double payrate = 80000;
		pay = payrate/ 24;
		DecimalFormat df = new DecimalFormat("###.##");
		//System.out.println("Salary in salaried class is: "+df.format(pay));
		return pay; 
		}
}
