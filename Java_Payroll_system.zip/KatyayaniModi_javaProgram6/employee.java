package application;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

abstract public class employee {	  
	 protected String loginName;
	 protected double salary;
	 protected String employeeName;
	 protected String date;
	 protected int employeeID;
	 protected String password;
	 static int nextID = 0;
public employee(){}

public String getpassword()
{
  return password;
}

// 3 parameters constructor to assign values whenever we add new employees.
public employee(String loginName1, double salary1, String employeeName1, String password1){
		 loginName = loginName1;
		 salary = salary1;
	     employeeName = employeeName1;
	     password = password1;
	     employeeID = employee.nextID;
	     nextID++;
	     DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		 LocalDate localDate = LocalDate.now();
		 date = dtf.format(localDate);
}
//5 parameters constructor to assign values at the time of reading file.
public employee(int employeeID1, String loginName1,double salary1, String date1,String employeeName1, String password1) {
		loginName = loginName1;
		salary = salary1;
		employeeName = employeeName1;
		date = date1;
		employeeID = employeeID1;
		password = password1;
}
public String toString() {
		return  String.format("%05d", employeeID) + "\t" + loginName + "\t" + salary + "\t" +password + "\t"+ date + "\t" + employeeName + "\n";
	}
}

